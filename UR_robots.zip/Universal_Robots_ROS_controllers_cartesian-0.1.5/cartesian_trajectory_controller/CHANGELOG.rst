^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package cartesian_trajectory_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.5 (2021-12-02)
------------------

0.1.4 (2021-08-05)
------------------
* Make control update open-loop without active action (`#5 <https://github.com/UniversalRobots/Universal_Robots_ROS_controllers_cartesian/issues/5>`_)
* Add websites to package.xml files
* Update image paths of partner logos (`#4 <https://github.com/UniversalRobots/Universal_Robots_ROS_controllers_cartesian/issues/4>`_)
* Contributors: Felix Exner, Stefan Scherzinger

0.1.3 (2021-06-23)
------------------

0.1.2 (2021-06-15)
------------------

0.1.1 (2021-06-15)
------------------
* Removed trailing whitespaces from README's
* Contributors: Felix Exner

0.1.0 (2021-06-15)
------------------
* Initial release
* Contributors: Felix Exner, Stefan Scherzinger
